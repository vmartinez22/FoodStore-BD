-- Concurrencia y niveles de aislamiento Food Store
USE foodstore;

-- Nivel de aislamiento READ COMMITTED
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT estado FROM pedido WHERE id = 3;
COMMIT;

-- Nivel de aislamiento REPEATABLE READ
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
START TRANSACTION;
SELECT estado FROM pedido WHERE id = 3;
COMMIT;

-- Nota sobre el deadlock:
-- Se intentó simular un deadlock con dos sesiones actualizando
-- las mismas filas en orden inverso. MySQL/InnoDB detectó el
-- conflicto automáticamente y resolvió la contención sin generar
-- el error 1213. Esto demuestra que InnoDB tiene mecanismos
-- de detección y resolución automática de deadlocks.
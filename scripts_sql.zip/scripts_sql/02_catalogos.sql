-- Datos base Food Store
USE foodstore;

INSERT INTO categoria (nombre, descripcion) VALUES 
('Pizzas', 'Pizzas artesanales'),
('Bebidas', 'Bebidas frias y calientes'),
('Hamburguesas', 'Hamburguesas artesanales'),
('Ensaladas', 'Ensaladas frescas'),
('Postres', 'Postres caseros'),
('Pastas', 'Pastas frescas');

INSERT INTO usuario (nombre, apellido, mail, celular, contrasena, rol) VALUES
('Victoria', 'Martinez', 'victoria@foodstore.com', '3825000001', '1234', 'ADMIN'),
('Renzo', 'Martinez', 'renzo@foodstore.com', '3825000002', '1234', 'USUARIO'),
('Gloria', 'Martinez', 'gloria@foodstore.com', '3825000003', '1234', 'USUARIO'),
('Luis', 'Capello', 'luis@foodstore.com', '3825000004', '1234', 'USUARIO'),
('Ana', 'Rodriguez', 'ana@foodstore.com', '3825000005', '1234', 'USUARIO');

INSERT INTO producto (nombre, precio, descripcion, stock, imagen, disponible, id_categoria) VALUES
('Hamburguesa Clasica', 10000, 'Medallon de carne, lechuga, tomate', 50, 'hamburguesa.jpg', TRUE, 3),
('Hamburguesa Doble', 15000, 'Doble medallon con queso', 40, 'hamburguesa2.jpg', TRUE, 3),
('Pizza Comun', 8000, 'Salsa de tomate y mozzarella', 30, 'pizza.jpg', TRUE, 1),
('Pizza Napolitana', 9000, 'Tomate, mozzarella y albahaca', 30, 'pizza2.jpg', TRUE, 1),
('Coca Cola', 2000, 'Bebida gaseosa 500ml', 100, 'coca.jpg', TRUE, 2),
('Agua Mineral', 1000, 'Agua mineral 500ml', 100, 'agua.jpg', TRUE, 2),
('Tiramisu', 5000, 'Postre italiano clasico', 20, 'tiramisu.jpg', TRUE, 5),
('Brownie', 3000, 'Brownie de chocolate', 25, 'brownie.jpg', TRUE, 5);
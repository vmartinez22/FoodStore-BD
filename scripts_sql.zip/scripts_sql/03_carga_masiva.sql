-- Carga masiva de datos Food Store
USE foodstore;

-- Generar 5000 pedidos
INSERT INTO pedido (fecha, estado, total, forma_pago, id_usuario)
SELECT 
    DATE_ADD('2024-01-01', INTERVAL FLOOR(RAND() * 365) DAY),
    ELT(FLOOR(RAND() * 4) + 1, 'PENDIENTE', 'CONFIRMADO', 'TERMINADO', 'CANCELADO'),
    0,
    ELT(FLOOR(RAND() * 3) + 1, 'TARJETA', 'TRANSFERENCIA', 'EFECTIVO'),
    FLOOR(RAND() * 5) + 1
FROM 
    information_schema.columns a,
    information_schema.columns b
LIMIT 5000;

-- Generar 10000 detalles de pedido
INSERT INTO detalle_pedido (cantidad, subtotal, id_pedido, id_producto)
SELECT 
    FLOOR(RAND() * 5) + 1,
    (FLOOR(RAND() * 5) + 1) * p.precio,
    ped.id,
    p.id
FROM 
    pedido ped,
    producto p
WHERE RAND() < 0.3
LIMIT 10000;
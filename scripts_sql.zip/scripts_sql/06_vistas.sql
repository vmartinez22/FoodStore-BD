-- Vistas Food Store
USE foodstore;

-- Vista 1: Usuarios sin datos sensibles
CREATE VIEW vista_usuarios_seguros AS
SELECT id, nombre, apellido, mail, rol
FROM usuario
WHERE eliminado = FALSE;

-- Vista 2: Pedidos publicos con nombre de usuario
CREATE VIEW vista_pedidos_publicos AS
SELECT p.id, u.nombre, u.apellido, p.fecha, p.estado, p.total
FROM pedido p
INNER JOIN usuario u ON p.id_usuario = u.id
WHERE p.eliminado = FALSE;

-- Vista 3: Pedidos con usuario (usada en Etapa 3)
CREATE VIEW vista_pedidos_usuarios AS
SELECT p.id, u.nombre, u.apellido, p.fecha, p.estado, p.forma_pago, p.total
FROM pedido p
INNER JOIN usuario u ON p.id_usuario = u.id
WHERE p.eliminado = FALSE;
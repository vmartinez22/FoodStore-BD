-- Seguridad Food Store
USE foodstore;

-- Crear usuario con privilegios minimos
CREATE USER 'operador_foodstore'@'localhost' IDENTIFIED BY 'operador123';
GRANT SELECT, INSERT, UPDATE ON foodstore.* TO 'operador_foodstore'@'localhost';
FLUSH PRIVILEGES;

-- Ver permisos del usuario
SHOW GRANTS FOR 'operador_foodstore'@'localhost';

-- Prueba de integridad 1: Violacion de UNIQUE (mail duplicado)
-- INSERT INTO usuario (nombre, apellido, mail, celular, contrasena, rol) 
-- VALUES ('Test', 'Test', 'victoria@foodstore.com', '123', '123', 'USUARIO');

-- Prueba de integridad 2: Violacion de CHECK (precio negativo)
-- INSERT INTO producto (nombre, precio, stock, id_categoria) 
-- VALUES ('Test', -500, 10, 1);

-- Procedimiento almacenado seguro (anti SQL injection)
DELIMITER //
CREATE PROCEDURE buscar_pedidos_por_usuario(IN p_id_usuario BIGINT)
BEGIN
    SELECT p.id, p.fecha, p.estado, p.total, p.forma_pago
    FROM pedido p
    WHERE p.id_usuario = p_id_usuario
    AND p.eliminado = FALSE;
END //
DELIMITER ;

-- Probar el procedimiento
CALL buscar_pedidos_por_usuario(1);
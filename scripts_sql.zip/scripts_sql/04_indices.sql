-- Indices Food Store
USE foodstore;

-- Indice en id_usuario para busquedas por usuario
CREATE INDEX idx_pedido_usuario ON pedido(id_usuario);

-- Indice en fecha para busquedas por rango de fechas
CREATE INDEX idx_pedido_fecha ON pedido(fecha);

-- Indice en estado para busquedas por estado
CREATE INDEX idx_pedido_estado ON pedido(estado);
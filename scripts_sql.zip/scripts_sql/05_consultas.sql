-- Consultas avanzadas Food Store
USE foodstore;

-- Consulta 1: JOIN - Pedidos con nombre de usuario
SELECT p.id, u.nombre, u.apellido, p.fecha, p.estado, p.forma_pago, p.total
FROM pedido p
INNER JOIN usuario u ON p.id_usuario = u.id
WHERE p.eliminado = FALSE
LIMIT 20;

-- Consulta 2: JOIN - Productos con su categoria
SELECT p.id, p.nombre, p.precio, p.stock, c.nombre AS categoria
FROM producto p
INNER JOIN categoria c ON p.id_categoria = c.id
WHERE p.eliminado = FALSE;

-- Consulta 3: GROUP BY + HAVING - Usuarios con mas de 100 pedidos
SELECT u.nombre, u.apellido, COUNT(p.id) AS cantidad_pedidos
FROM usuario u
INNER JOIN pedido p ON u.id = p.id_usuario
GROUP BY u.id, u.nombre, u.apellido
HAVING COUNT(p.id) > 100;

-- Consulta 4: Subconsulta - Productos con precio mayor al promedio
SELECT nombre, precio
FROM producto
WHERE precio > (SELECT AVG(precio) FROM producto)
AND eliminado = FALSE;
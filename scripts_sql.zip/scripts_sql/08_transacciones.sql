-- Transacciones Food Store
USE foodstore;

-- Ejemplo 1: Transaccion exitosa con COMMIT
START TRANSACTION;
UPDATE pedido SET estado = 'CONFIRMADO' WHERE id = 3;
UPDATE pedido SET total = 5000 WHERE id = 3;
COMMIT;

-- Verificar que los cambios se aplicaron
SELECT id, estado, total FROM pedido WHERE id = 3;

-- Ejemplo 2: Transaccion con ROLLBACK
START TRANSACTION;
UPDATE pedido SET estado = 'CANCELADO' WHERE id = 3;
ROLLBACK;

-- Verificar que los cambios NO se aplicaron
SELECT id, estado, total FROM pedido WHERE id = 3;
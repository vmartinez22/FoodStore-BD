Food Store - TFI Bases de Datos I
Alumna: Martinez, Victoria Abigail
Comisión 8 - UTN TUPaD

Orden de ejecución de scripts:
1. 01_esquema.sql - Creación de tablas y constraints
2. 02_catalogos.sql - Datos base (categorías, usuarios, productos)
3. 03_carga_masiva.sql - Generación de 15.000+ registros
4. 04_indices.sql - Creación de índices
5. 05_consultas.sql - Consultas avanzadas (JOIN, GROUP BY, subconsulta)
6. 06_vistas.sql - Vistas de seguridad
7. 07_seguridad.sql - Usuario, permisos y procedimiento almacenado
8. 08_transacciones.sql - Transacciones con COMMIT y ROLLBACK
9. 09_concurrencia_guiada.sql - Niveles de aislamiento

Requisitos:
- MySQL 8.0+
- MySQL Workbench
- Puerto: 3307